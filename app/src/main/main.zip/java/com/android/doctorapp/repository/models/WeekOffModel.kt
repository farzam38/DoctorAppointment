package com.android.doctorapp.repository.models

data class WeekOffModel(
    var dayName: String = "",
    var isWeekOff: Boolean = false
)
