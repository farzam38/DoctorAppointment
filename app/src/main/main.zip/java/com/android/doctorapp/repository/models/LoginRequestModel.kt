package com.android.doctorapp.repository.models

data class LoginRequestModel(
    val email: String,
    val password: String,
)
