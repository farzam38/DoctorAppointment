package com.android.doctorapp.repository.models

import android.net.Uri

data class ImageUriAndGender(
    var imageUri: Uri?,
    var gender: String?
)
