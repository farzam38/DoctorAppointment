package com.android.doctorapp.repository.models

data class WeekOffRequestModel (
    var dayName: String = ""
)