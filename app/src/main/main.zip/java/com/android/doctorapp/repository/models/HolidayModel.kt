package com.android.doctorapp.repository.models

import java.util.Date

data class HolidayModel(
    var holidayDate: Date? = null
)