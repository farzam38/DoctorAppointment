package com.android.doctorapp.di

interface AppComponentProvider {
    fun getAppComponent(): AppComponent
}
