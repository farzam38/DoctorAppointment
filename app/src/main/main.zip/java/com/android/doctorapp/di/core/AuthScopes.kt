package com.android.doctorapp.di.core

import javax.inject.Scope

@Scope
@Retention(AnnotationRetention.SOURCE)
annotation class AuthScopes
