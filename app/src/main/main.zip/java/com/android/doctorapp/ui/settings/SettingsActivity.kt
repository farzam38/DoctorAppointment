package com.android.doctorapp.ui.settings

import com.android.doctorapp.R
import com.android.doctorapp.databinding.ActivitySettingsBinding
import com.android.doctorapp.di.base.BaseActivity

class SettingsActivity: BaseActivity<ActivitySettingsBinding>(R.layout.activity_settings) {
}