package com.android.doctorapp.di.core

interface CoreComponentProvider {

    fun getCoreComponent(): CoreComponent
}
